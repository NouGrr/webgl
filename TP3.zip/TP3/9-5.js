"use strict"; // good practice - see https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Strict_mode
////////////////////////////////////////////////////////////////////////////////
// Change from fixed steps to timed updates
////////////////////////////////////////////////////////////////////////////////
/*global THREE, Coordinates, document, window, container, Stats, $*/

import * as THREE from 'three';

import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import {dat} from '../lib/dat.gui.min.js';


let camera, scene, renderer;
let cameraControls;
let clock = new THREE.Clock();

function init() {
    const canvasWidth = 846;
    const canvasHeight = 494;
    const aspectRatio = canvasWidth / canvasHeight;

    // Renderer
    renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.gammaInput = true;
    renderer.gammaOutput = true;
    renderer.setSize(canvasWidth, canvasHeight);
    renderer.setClearColor(0x808080, 1.0);
    document.getElementById('webGL').appendChild(renderer.domElement);

    // Camera
    camera = new THREE.PerspectiveCamera(45, aspectRatio, 10, 10000);
    camera.position.set(0, 0, 1000);

    // Controls
    cameraControls = new OrbitControls(camera, renderer.domElement);
    cameraControls.target.set(0, 0, 0);

    // Scene
    scene = new THREE.Scene();
    scene.fog = new THREE.Fog(0x808080, 500, 10000); 

    // Lights
    const ambientLight = new THREE.AmbientLight(0x222222);
    scene.add(ambientLight);

    const light1 = new THREE.DirectionalLight(0xFFFFFF, 1.0);
    light1.position.set(200, 400, 500);
    scene.add(light1);

    const light2 = new THREE.DirectionalLight(0xFFFFFF, 1.0);
    light2.position.set(-400, 200, -300);
    scene.add(light2);

    // Image principale (LeBonCri.png)
    const textureLoader = new THREE.TextureLoader();
    const imageTexture = textureLoader.load('textures/LeBonCri.png');
    const imageSize = { width: 1500, height: 800 };

    const imageMaterial = new THREE.MeshBasicMaterial({ map: imageTexture, transparent: true });
    const imageGeometry = new THREE.PlaneGeometry(imageSize.width, imageSize.height);
    const imagePlane = new THREE.Mesh(imageGeometry, imageMaterial);
    imagePlane.position.set(0, -250, -1000); // Avancé de 250 unités vers le spectateur
    scene.add(imagePlane);

    // Plan transparent devant l'image principale
    const transparentMaterial = new THREE.MeshPhongMaterial({ color: 0xffffff, transparent: true, opacity: 0.5 });
    const transparentGeometry = new THREE.PlaneGeometry(imageSize.width, imageSize.height);
    const transparentPlane = new THREE.Mesh(transparentGeometry, transparentMaterial);
    transparentPlane.position.set(0, -250, -999); // Légèrement devant l'image principale pour l'effet de vitre
    scene.add(transparentPlane);

    // Image d'arrière-plan
    const backgroundTexture = textureLoader.load('textures/background.png'); // Remplacez 'autre_image.png' par le chemin de votre autre image
    const backgroundMaterial = new THREE.MeshBasicMaterial({ map: backgroundTexture });
    const backgroundPlane = new THREE.Mesh(imageGeometry, backgroundMaterial);
    backgroundPlane.position.set(0, -300, -1250); // Positionné derrière l'image principale
    scene.add(backgroundPlane);

    // Ajout d'un pont avec plusieurs planches (existant dans votre code)
    const plankWidth = 1000;
    const plankHeight = 10;
    const plankDepth = 1000;
    const numPlanks = 10;
    const plankSpacing = 5;
    const bridgeMaterial = new THREE.MeshLambertMaterial({ color: 0x8B4513 });

    for (let i = 0; i < numPlanks; i++) {
        const plankGeometry = new THREE.BoxGeometry(plankWidth, plankHeight, plankDepth);
        const plank = new THREE.Mesh(plankGeometry, bridgeMaterial);
        plank.position.set(i * (plankWidth + plankSpacing) - (numPlanks * (plankWidth + plankSpacing)) / 2, -700, -749);
        scene.add(plank);
    }

    // GUI (existant dans votre code)
    const gui = new dat.GUI();
    const light1Folder = gui.addFolder('Light 1');
    light1Folder.add(light1.position, 'x', -1000, 1000).name('X');
    light1Folder.add(light1.position, 'y', -1000, 1000).name('Y');
    light1Folder.add(light1.position, 'z', -1000, 1000).name('Z');

    const light2Folder = gui.addFolder('Light 2');
    light2Folder.add(light2.position, 'x', -1000, 1000).name('X');
    light2Folder.add(light2.position, 'y', -1000, 1000).name('Y');
    light2Folder.add(light2.position, 'z', -1000, 1000).name('Z');

    const cameraFolder = gui.addFolder('Camera');
    cameraFolder.add(camera.position, 'x', -1000, 1000).name('X');
    cameraFolder.add(camera.position, 'y', -1000, 1000).name('Y');
    cameraFolder.add(camera.position, 'z', -1000, 1000).name('Z');

    // Animation
    animate();
}





function animate() {
    window.requestAnimationFrame(animate);
    render();
}

function render() {
    const delta = clock.getDelta();
    cameraControls.update(delta);
    renderer.render(scene, camera);
}

init();
