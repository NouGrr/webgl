"use strict"; // good practice - see https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Strict_mode
/*global THREE, Coordinates, $, document, window, dat*/
import * as THREE from "three";
import { OBJLoader } from "three/addons/loaders/OBJLoader.js";
import { OrbitControls } from "three/addons/controls/OrbitControls.js";
import { dat } from "/lib/dat.gui.min.js";
import { Coordinates } from "../lib/Coordinates.js";
import { TeapotGeometry } from 'three/addons/geometries/TeapotGeometry.js';

let camera, renderer;
let cameraControls;
const clock = new THREE.Clock();
const teapotSize = 50;

// Vertex Shader
const vertexShader = `
varying vec3 vNormal;
varying vec3 vViewPosition;
varying vec3 vModelPosition;

void main() {
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
    vNormal = normalize(normalMatrix * normal);
    vec4 mvPosition = modelViewMatrix * vec4(position, 1.0);
    vViewPosition = -mvPosition.xyz;
    vModelPosition = position;
}
`;

// Fragment Shader
const fragmentShader = `
uniform vec3 uMaterialColor;
uniform vec3 uDirLightPos;
uniform vec3 uDirLightColor;
uniform float uKd;
uniform float uBorder;
uniform float uScale;

varying vec3 vNormal;
varying vec3 vViewPosition;
varying vec3 vModelPosition;

void main() {
    // Compute direction to light
    vec4 lDirection = viewMatrix * vec4(uDirLightPos, 0.0);
    vec3 lVector = normalize(lDirection.xyz);

    // Diffuse: N * L. Normal must be normalized, since it's interpolated.
    vec3 normal = normalize(vNormal);

    float diffuse = max(dot(normal, lVector), 0.0);
    diffuse = (diffuse > uBorder) ? 1.0 : 0.5;

    // Procedural texture
    float textureValue = 0.5 + 0.5 * sin(uScale * vModelPosition.x) * sin(uScale * vModelPosition.y) * sin(uScale * vModelPosition.z);

    // Combine diffuse lighting with procedural texture
    vec3 finalColor = uKd * uMaterialColor * uDirLightColor * diffuse * textureValue;
    gl_FragColor = vec4(finalColor, 1.0);
}
`;

function createShaderMaterial(light) {
    const shaderMaterial = new THREE.ShaderMaterial({
        uniforms: {
            uMaterialColor: { type: 'c', value: new THREE.Color(0x00FF00) }, // Changed to green color
            uDirLightPos: { type: 'v3', value: light.position },
            uDirLightColor: { type: 'c', value: light.color },
            uKd: { type: 'f', value: 0.7 },
            uBorder: { type: 'f', value: 0.4 },
            uScale: { type: 'f', value: 1.0 }
        },
        vertexShader: vertexShader,
        fragmentShader: fragmentShader,
        side: THREE.DoubleSide
    });
    return shaderMaterial;
}

function fillScene() {
    window.scene = new THREE.Scene();
    // LIGHTS
    window.scene.add(new THREE.AmbientLight(0x333333));
    let light = new THREE.DirectionalLight(0xFFFFFF, 0.9);
    light.position.set(200, 300, 500);
    window.scene.add(light);
    light = new THREE.DirectionalLight(0xFFFFFF, 0.7);
    light.position.set(-200, -100, -400);
    window.scene.add(light);

    const material = createShaderMaterial(light);
    const teapot = new THREE.Mesh(
        new TeapotGeometry(teapotSize, 10, true, true, true, false, true),
        material
    );
    window.scene.add(teapot);
    return material; // Added return statement to pass the material to setupGui
}

function init() {
    const canvasWidth = 846;
    const canvasHeight = 494;
    // For grading the window is fixed in size; here's general code:
    //var canvasWidth = window.innerWidth;
    //var canvasHeight = window.innerHeight;

    // CAMERA
    camera = new THREE.PerspectiveCamera(45, canvasWidth / canvasHeight, 100, 20000);
    camera.position.set(-222, 494, 1746);

    // RENDERER
    renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(canvasWidth, canvasHeight);
    renderer.setClearColor(0xAAAAAA, 1.0);
    renderer.gammaInput = true;
    renderer.gammaOutput = true;

    // CONTROLS
    cameraControls = new OrbitControls(camera, renderer.domElement);
    cameraControls.target.set(0, -160, 0);
}

function addToDOM() {
    const container = document.getElementById('webGL');
    const canvas = container.getElementsByTagName('canvas');
    if (canvas.length > 0) {
        container.removeChild(canvas[0]);
    }
    container.appendChild(renderer.domElement);
}

function setupGui(material) {
    const effectController = {
        kd: 0.7,
        border: 0.4,
        hue: 0.09,
        saturation: 0.46,
        lightness: 0.7,
        lx: 0.32,
        ly: 0.39,
        lz: 0.7,
        scale: 1.0
    };

    const gui = new dat.GUI();

    gui.add(effectController, 'kd', 0.0, 1.0, 0.025).name('Kd').onChange(updateMaterial);
    gui.add(effectController, 'border', 0.0, 1.0, 0.025).name('Border').onChange(updateMaterial);
    gui.add(effectController, 'scale', 0.0, 10.0, 0.1).name('Scale').onChange(updateMaterial);

    function updateMaterial() {
        material.uniforms.uKd.value = effectController.kd;
        material.uniforms.uBorder.value = effectController.border;
        material.uniforms.uScale.value = effectController.scale;
    }
}

function animate() {
    requestAnimationFrame(animate);
    render();
}

function render() {
    const delta = clock.getDelta();
    cameraControls.update(delta);
    renderer.render(window.scene, camera);
}

try {
    init();
    const material = fillScene();
    setupGui(material);
    addToDOM();
    animate();
} catch (e) {
    const errorReport = "Your program encountered an unrecoverable error, can not draw on canvas. Error was:<br/><br/>";
    $('#webGL').append(errorReport + e.stack);
}
